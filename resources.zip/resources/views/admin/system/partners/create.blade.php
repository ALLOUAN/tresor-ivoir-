@extends('layouts.app')

@section('title', 'Nouveau partenaire')
@section('page-title', 'Tableau de bord')

@section('header-actions')
    <a href="{{ route('admin.administration.partners') }}"
        class="inline-flex items-center gap-2 text-sm text-slate-400 hover:text-white transition">
        <i class="fas fa-arrow-left"></i> Retour
    </a>
@endsection

@section('content')

    <nav class="text-xs text-slate-500 mb-6">
        <a href="{{ route('admin.dashboard') }}" class="hover:text-slate-300">Tableau de bord</a>
        <span class="mx-1.5">/</span>
        <a href="{{ route('admin.administration.partners') }}" class="hover:text-slate-300">Partenaires</a>
        <span class="mx-1.5">/</span>
        <span class="text-slate-400">Nouveau</span>
    </nav>

    @if($errors->any())
        <div class="mb-5 px-4 py-3 bg-red-900/30 border border-red-800 text-red-300 text-sm rounded-xl">
            <ul class="list-disc list-inside space-y-1">
                @foreach($errors->all() as $err)
                    <li>{{ $err }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form method="POST" action="{{ route('admin.administration.partners.store') }}" enctype="multipart/form-data" class="space-y-6">
        @csrf
        @include('admin.system.partners._form-fields', ['partner' => $partner, 'typeOptions' => $typeOptions])

        <div class="flex justify-end pt-2">
            <button type="submit"
                class="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-sm font-semibold text-white bg-green-600 hover:bg-green-500 shadow-lg transition">
                <i class="fas fa-check"></i> Créer le partenaire
            </button>
        </div>
    </form>

@endsection
