<!DOCTYPE html>
<html lang="fr" id="html-root" class="overflow-x-hidden">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Annuaire des prestataires — {{ $siteBrand['site_name'] }}</title>
    @include('partials.theme-init')
    @include('partials.theme-light-bridge')
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        body { font-family: 'Inter', sans-serif; }
        .font-serif { font-family: 'Playfair Display', serif; }
        .providers-filter-shell {
            box-shadow: 0 12px 28px rgba(0,0,0,0.18);
        }
        .provider-list-card {
            transition: transform .2s ease, border-color .2s ease, box-shadow .2s ease;
        }
        .provider-list-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.2);
        }
        html:not(.dark) .providers-filter-shell {
            background:#e9e5d9 !important;
            border-color: rgba(0,0,0,0.08) !important;
            box-shadow: 0 12px 26px rgba(0,0,0,0.06);
        }
        html:not(.dark) .provider-list-card {
            background:#e9e5d9 !important;
            border-color: rgba(0,0,0,0.08) !important;
            box-shadow: 0 10px 22px rgba(0,0,0,0.05);
        }
        /* Image de fond configurable (back-office) du bandeau de la page Annuaire. */
        .providers-hero {
            background-image: linear-gradient(rgba(233,229,217,.55), rgba(233,229,217,.55));
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        .providers-hero[style*="--providers-hero-bg-image"] {
            background-image: var(--providers-hero-bg-image, none);
        }
    </style>
</head>
<body class="bg-[#ffffff] text-white">
    @include('partials.page-background')
    @include('partials.public-top-nav')

    @php
        $providersHeroImage = \Illuminate\Support\Facades\Schema::hasTable('providers_hero_images')
            ? \App\Models\ProvidersHeroImage::query()->find(1)
            : null;
    @endphp

    <section class="relative py-20 overflow-hidden {{ ($providersHeroImage && $providersHeroImage->isVisible()) ? 'providers-hero' : '' }}"
        @if($providersHeroImage && $providersHeroImage->isVisible())
            style="--providers-hero-bg-image: url('{{ $providersHeroImage->image_url }}');"
        @endif
    >
        <div class="absolute inset-0 bg-gradient-to-b from-orange-900/20 to-transparent pointer-events-none"></div>
        <a href="{{ route('home') }}" class="absolute top-6 right-6 z-10 text-orange-400 text-sm hover:text-orange-300 transition">Retour accueil</a>
        <div class="max-w-6xl mx-auto px-6 text-center relative z-10">
            <div class="inline-block rounded-2xl bg-green-950/70 backdrop-blur-md px-6 py-8 sm:px-12 sm:py-10">
                <p class="text-orange-400 text-sm font-medium uppercase tracking-widest mb-3">Annuaire</p>
                <h1 class="font-serif text-4xl md:text-5xl font-bold text-white mb-4">
                    Annuaire des prestataires
                </h1>
                <p class="text-gray-200 text-xl max-w-2xl mx-auto">
                    Trouvez les meilleures adresses par ville, catégorie et gamme de prix.
                </p>
            </div>
        </div>
    </section>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 py-8 sm:py-10">
        <div class="providers-filter-shell bg-[#ffffff] border border-white/8 rounded-xl p-4 mb-6">
            <form method="GET" action="{{ route('providers.index') }}" class="grid grid-cols-1 md:grid-cols-6 gap-3">
                <input
                    type="text"
                    name="q"
                    value="{{ $search }}"
                    placeholder="Nom, ville ou description..."
                    class="md:col-span-2 bg-[#ffffff] border border-white/10 rounded-lg px-3 py-2 text-sm"
                >
                <select name="categorie" class="bg-[#ffffff] border border-white/10 rounded-lg px-3 py-2 text-sm">
                    <option value="">Toutes catégories</option>
                    @foreach($categories as $cat)
                        <option value="{{ $cat->slug }}" @selected($activeCategory?->id === $cat->id)>
                            {{ $cat->name_fr }} ({{ $cat->providers_count }})
                        </option>
                    @endforeach
                </select>
                <select name="ville" class="bg-[#ffffff] border border-white/10 rounded-lg px-3 py-2 text-sm">
                    <option value="">Toutes villes</option>
                    @foreach($cities as $v)
                        <option value="{{ $v }}" @selected($city === $v)>{{ $v }}</option>
                    @endforeach
                </select>
                <select name="prix" class="bg-[#ffffff] border border-white/10 rounded-lg px-3 py-2 text-sm">
                    <option value="">Tous prix</option>
                    @foreach(['budget' => 'Budget', 'mid' => 'Moyen', 'premium' => 'Premium', 'luxury' => 'Luxe'] as $value => $label)
                        <option value="{{ $value }}" @selected($price === $value)>{{ $label }}</option>
                    @endforeach
                </select>
                <select name="tri" class="bg-[#ffffff] border border-white/10 rounded-lg px-3 py-2 text-sm">
                    <option value="rating" @selected($sort === 'rating')>Tri: mieux notés</option>
                    <option value="name" @selected($sort === 'name')>Tri: nom</option>
                    <option value="newest" @selected($sort === 'newest')>Tri: plus récents</option>
                    <option value="views" @selected($sort === 'views')>Tri: plus vus</option>
                </select>
                <label class="md:col-span-2 text-gray-300 text-sm flex items-center gap-2">
                    <input type="checkbox" name="verifie" value="1" @checked(request()->boolean('verifie'))>
                    Prestataires vérifiés uniquement
                </label>
                <div class="md:col-span-4 flex items-center gap-2">
                    <button type="submit" class="bg-orange-500 hover:bg-orange-600 text-black font-semibold text-sm px-4 py-2 rounded-lg">Filtrer</button>
                    <a href="{{ route('providers.index') }}" class="bg-[#ffffff] hover:bg-[#ffffff] border border-white/10 text-white text-sm px-4 py-2 rounded-lg transition">Réinitialiser</a>
                </div>
            </form>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            @forelse($providers as $provider)
                <a href="{{ route('providers.show', $provider->slug) }}" class="provider-list-card bg-[#ffffff] border border-white/5 rounded-xl overflow-hidden hover:border-orange-500/40 transition">
                    <div class="h-40 bg-[#ffffff]">
                        @if($provider->cover_url)
                            <img src="{{ $provider->cover_url }}" alt="{{ $provider->name }}" class="w-full h-full object-cover">
                        @else
                            <div class="w-full h-full flex items-center justify-center text-gray-600">
                                <i class="fas fa-store text-3xl"></i>
                            </div>
                        @endif
                    </div>
                    <div class="p-4">
                        <div class="flex items-center justify-between gap-2">
                            <p class="text-white font-semibold">{{ $provider->name }}</p>
                            @if($provider->is_verified)
                                <span class="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-1 rounded-full">Vérifié</span>
                            @endif
                        </div>
                        <p class="text-gray-500 text-xs mt-1">{{ $provider->category->name_fr ?? 'Catégorie' }} · {{ $provider->city ?: 'N/A' }}</p>
                        <p class="text-gray-300 text-sm mt-2">{{ $provider->short_desc_fr ?: \Illuminate\Support\Str::limit($provider->description_fr, 90) }}</p>
                        <div class="mt-3 flex items-center justify-between text-xs">
                            <span class="text-orange-400">{{ number_format((float) ($provider->rating_avg ?? 0), 1) }} ★</span>
                            <span class="text-gray-500 uppercase">{{ $provider->price_range ?: 'n/a' }}</span>
                        </div>
                    </div>
                </a>
            @empty
                <div class="col-span-3 bg-[#ffffff] border border-white/8 rounded-xl p-8 text-center text-gray-500">
                    Aucun prestataire trouvé avec ces filtres.
                </div>
            @endforelse
        </div>

        <div class="mt-6">
            {{ $providers->links() }}
        </div>
    </div>
@include('partials.homepage-footer')
@include('partials.image-protection')
</body>
</html>
